# CS 396 Final Project

Please use this repository to share any code or resources you use for your
final project. You will turn in written work (proposal, update, and final
report) via Canvas, but you will be required to provide your code when we
grade your final report. Please keep that code here.

This repository should contain everything you use for the project, with the
exception of any datasets that are protected (e.g., contain patient data) or
are larger than 50 MB.
